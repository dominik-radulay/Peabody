﻿namespace Unity.Screenshots
{
    public enum ScreenshotType
    {
        Raw = 0,

        Png = 1
    }
}